exports.server_port = 3000

exports.admin_username = 'admin'
exports.admin_password = 'admin'